#include <bits/stdc++.h>
#include "rectangle.h"
using namespace std;

int main() {

    Rectangle r(2,3);
    cout<<r.calculate_area()<<endl;
    cout<<r.calculate_perimeter()<<endl;

    return 0;
}