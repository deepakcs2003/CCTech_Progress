#pragma once
#include<bits./stdc++.h>
class Rectangle {
    private:
    int length;
    int width;
    public:
    Rectangle(int length,int width);
    int calculate_area();
    int calculate_perimeter();

};